import pandas as pd
import numpy as np
import csv
import konlpy
from konlpy.tag import Okt

### initial set 

dir_critical_words_p = "/critical_words_p.txt"
dir_critical_words_n = "/critical_words_n.txt"

dir_comments = "/compiled_non_brand.csv"

### get critical words

critical_words_p = []
critical_words_n = []

with open(dir_critical_words_p, mode="r") as p:
    positive = p.readlines()

with open(dir_critical_words_n, mode="r") as n:
    negative = n.readlines()

for pw in positive:
    critical_words_p.append(pw.strip())
    
for nw in negative:
    critical_words_n.append(nw.strip())

### classfy critical sentence

flag = 0 
# 1 : p ,0 : m ,-1 : n

### get comments

comments = []

with open(dir_comments, mode="r") as c:
    comments_csv = csv.reader(c)
    comments = list(comments_csv)

negative_comments = []

for cmt in comments:
    if cmt[1] == '-1':
        print(cmt[0])
        negative_comments.append(cmt[0])

okt=Okt()

negative_comments_splited = []
for n_cmt in negative_comments:
    negative_comments_splited.append(okt.morphs(n_cmt,stem=True))

for ncs in negative_comments_splited:
    print(ncs)

from collections import Counter

bad_words=[]

for ncs in negative_comments_splited:
    for bad_word in ncs:
        bad_words.append(bad_word)
        
result_bad_words = Counter(bad_words) 

#for result in result_bad_words:
    #print(result,result_bad_words[result])

sorted_bad_words = sorted(result_bad_words.items(),key=lambda x: x[1], reverse=True)

for result in sorted_bad_words:
    print(result[0],",",result[1])

print("number of comments : ", len(comments))
print("number of negative comments : " ,len(negative_comments))
print("number of bad words : " ,len(sorted_bad_words))