## youtube comment crawler

import sys, os
from bs4 import BeautifulSoup
from selenium import webdriver
import urllib.request, urllib
import requests
import random,time
import pandas as pd
import numpy as np
from selenium.webdriver.common.keys import Keys
import csv

###sample

url_sample= "https://www.youtube.com/watch?v=xmvHu13ZInY"
videoName_sample = "회사원A"
videoNum_sample = 0

###initial set
root_folder = "C:/Users/luraw/OneDrive/바탕 화면/youtube text/"
webDriver = "C:/Users/luraw/OneDrive/바탕 화면/chromedriver.exe"
download_list_dir = "C:/Users/luraw/OneDrive/바탕 화면/youtube text/downloadList.txt"

browser = webdriver.Chrome(webDriver)
fileCount = 0

def getDownloadList():
    url_list_ = []
    videoName_list_=[]
    videoNum_list_ =[]

    with open(download_list_dir,'r',encoding='UTF8') as dl:
        lines = csv.reader(dl)
        lines = list(lines)
        print(lines)
        for line in lines[1:]:
            url_list_.append(str(line[0]))
            videoName_list_.append(str(line[1]))
            videoNum_list_.append(str(line[2]))

    print("downloaded List")
    for line in lines[1:]:
        print(line[1])
    return url_list_,videoName_list_,videoNum_list_

def downLoadComments(url = url_sample, videoName = videoName_sample, videoNum= videoNum_sample):
    global fileCount
    saveDir = root_folder+videoName
    saveFile = videoName+"_"+str(videoNum)

    browser.get(url)
    time.sleep(0.5)

    ### page down

    page_height = browser.execute_script("return document.documentElement.scrollHeight")
    scroll_waiting_time = 3

    while True:
        browser.execute_script("window.scrollTo(0, document.documentElement.scrollHeight);")
        # document.documentElement.scrollHeight : height of the page
        time.sleep(scroll_waiting_time)
        scrolled_height = browser.execute_script("return document.documentElement.scrollHeight")

        if page_height == scrolled_height:
            # It didn't move => The end of the page
            break
        else:
            page_height = scrolled_height

    time.sleep(1)

    ### refine html data

    html = browser.page_source

    soup = BeautifulSoup(html, 'lxml')

    comment_id = soup.select('div#header-author > a > span')
    comment_text = soup.select('yt-formatted-string#content-text')

    str_comment_id = []
    str_comment_text =[]

    for ci in comment_id:
        str_comment_id.append(str(ci.text).replace('\t','').replace('\n','').replace(' ',''))
        

    for comment in comment_text:
        str_comment_text.append(str(comment.text).replace('\t','').replace('\n',''))

    fileCount += len(comment_id)

    ### make folder and save picture in that directory

    try:
        if not(os.path.isdir(saveDir)):
            os.makedirs(os.path.join(saveDir))
    except OSError as e:
        print(e+"Failed to create directory")

    data_frame = {"ID":str_comment_id, "comment":str_comment_text}
    
    fileName_ = saveDir+"/"+saveFile+".csv"
    pd.DataFrame(data_frame).to_csv(fileName_, encoding="UTF8")

    print("Saved :: "+saveFile)

url_list, videoName_list, videoNum_list = getDownloadList()

for i in range(len(url_list)):
    downLoadComments(url_list[i], videoName_list[i], videoNum_list[i])

print("complete")
print("saved files : ", fileCount)