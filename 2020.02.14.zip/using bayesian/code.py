import pandas as pd
import numpy as np
import csv
import konlpy
from konlpy.tag import Okt

### initial set 

dir_comments = "/compiled_non_brand.csv"

### define bayesian filter

import math, sys
from konlpy.tag import Twitter

class BayesianFilter:
    def __init__(self):
        self.words = set()
        self.word_dict = {}
        self.category_dict = {}

    def split(self, text):
        results = []
        twitter = Twitter()
        malist = twitter.pos(text, norm=True, stem=True)
        for word in malist:
            if not word[1] in ['Josa', 'Eomi', 'Punctuation']:
                results.append(word[0])
        return results

    def inc_word(self, word, category):
        if not category in self.word_dict:
            self.word_dict[category] = {}
        if not word in self.word_dict[category]:
            self.word_dict[category][word] = 0
        self.word_dict[category][word] += 1
        self.words.add(word)

    def inc_category(self, category):
        if category not in self.category_dict:
            self.category_dict[category] = 0
        self.category_dict[category] += 1

    def fit(self, text, category):
        word_list = self.split(text)
        for word in word_list:
            self.inc_word(word, category)
        self.inc_category(category)

    def score(self, words, category):
        score = math.log(self.category_prob(category))
        for word in words:
            score += math.log(self.word_prob(word, category))
        return score

    def predict(self, text):
        best_category = None
        max_score = -sys.maxsize
        words = self.split(text)
        score_list = []
        for category in self.category_dict.keys():
            score = self.score(words, category)
            score_list.append((category, score))
            if score > max_score:
                max_score = score
                best_category = category
        return best_category, score_list

    def get_word_count(self, word, category):
        if word in self.word_dict[category]:
            return self.word_dict[category][word]
        else:
            return 0

    def category_prob(self, category):
        sum_categories = sum(self.category_dict.values())
        category_v = self.category_dict[category]
        return category_v / sum_categories

    def word_prob(self, word, category):
        n = self.get_word_count(word, category) + 1
        d = sum(self.word_dict[category].values()) + len(self.words)
        return n / d

# fit

bf = BayesianFilter()

with open(dir_comments, mode="r") as c:
    comments_csv = csv.reader(c)
    comments = list(comments_csv)

X_data =[]
y_data =[]

for cmt in comments[0:3000]:
    bf.fit(cmt[0],cmt[1])

# predict


dir_bf_predict="/predictList-noMiddle.csv"

with open(dir_bf_predict, mode="r") as c:
    pre_csv = csv.reader(c)
    pre_list = list(pre_csv)

score =0    

for i in range(len(pre_list)):
    p,labelling = bf.predict(pre_list[i][0])
    print(pre_list[i], end=' : ')
    print(p)
    if pre_list[i][1] == p:
        score+=1
    

print(score/len(pre_list))

dir_bf_predict="/predictList.csv"

with open(dir_bf_predict, mode="r") as c:
    pre_csv = csv.reader(c)
    pre_list = list(pre_csv)

score =0    

wrong=[]

with open('/wrong.txt', mode="w") as wf:
    for i in range(len(pre_list)):
        p,labelling = bf.predict(pre_list[i][0])
        print(pre_list[i], end=' : ')
        print(p)
        if pre_list[i][1] == p:
            score+=1
        else:
            wf.write(pre_list[i][0]+" => "+ str(p)+"\n")
    
print(score/len(pre_list))
